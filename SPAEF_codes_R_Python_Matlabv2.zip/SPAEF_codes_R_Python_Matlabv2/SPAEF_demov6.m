clear
clc
close all

addpath('.\matlab_files')

mask = import_2Dmask('.\map_files\mask_1km.asc');

obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_1.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));



[ spaef_1, alpha1, beta1, gamma1 ] = SPAEF_func( sim_vec,obs_vec );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_2.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

[ spaef_2, alpha2, beta2, gamma2 ] = SPAEF_func( sim_vec,obs_vec );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_3.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

[ spaef_3, alpha3, beta3, gamma3 ] = SPAEF_func( sim_vec,obs_vec );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_4.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));



[ spaef_4, alpha4, beta4, gamma4 ] = SPAEF_func( sim_vec,obs_vec );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_5.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));


[ spaef_5, alpha5, beta5, gamma5 ] = SPAEF_func( sim_vec,obs_vec );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_6.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));


[ spaef_6, alpha6, beta6, gamma6 ] = SPAEF_func( sim_vec,obs_vec );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_shuffled.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));


[ spaef_7, alpha7, beta7, gamma7 ] = SPAEF_func( sim_vec,obs_vec );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\obs.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=obs_vec*1.4;


[ spaef_8, alpha8, beta8, gamma8 ] = SPAEF_func( sim_vec,obs_vec );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\obs.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=obs_vec+2;


[ spaef_9, alpha9, beta9, gamma9 ] = SPAEF_func( sim_vec,obs_vec );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\obs.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=obs_vec.^2;


[ spaef_10, alpha10, beta10, gamma10 ] = SPAEF_func( sim_vec,obs_vec );

fileID = fopen('.\results\SPAEF_results.txt','w');
fprintf(fileID,'%5s %5s \r\n','ID','SPAEF') 
fprintf(fileID,'%3s %.6f \r\n','Case1', spaef_1 ,'Case2',spaef_2,'Case3',spaef_3,'Case4',spaef_4,'Case5',spaef_5,'Case6',spaef_6,'Case7',spaef_7,'Case8',spaef_8,'Case9',spaef_9,'Case10',spaef_10);


