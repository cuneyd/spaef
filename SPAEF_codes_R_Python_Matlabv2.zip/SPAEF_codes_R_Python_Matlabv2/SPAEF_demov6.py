# -*- coding: utf-8 -*-


from __future__ import print_function
print(__doc__)

import numpy as np
import sys,csv


sys.path.append('./py_files')


from SPAEF_metric import SPAEF
from figures import plot_SPAEFstats, plot_maps


mask_1km = np.loadtxt('./map_files/mask_1km.asc', delimiter=',')   # X is an array

dpi = 60 # Arbitrary. The number of pixels in the image will always be identical
height, width = [12,18]#np.array(aET_sim.shape, dtype=float) / dpi
font = {'family': 'serif',
        'color':  'black',
        'weight': 'bold',
        'size': 16,
        }

obs=[]
sim=[]
############################################################ EXAMPLE: descent monthly match
obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/sim_1.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=simm[np.isnan(obss)==False]


SPAef1, alpha1, beta1, gamma1 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef1, alpha1, beta1, gamma1,'Case-1') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map1map') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case1',SPAef1)

############################################################ EXAMPLE: better monthly match

obs=[]
sim=[]
obss=[]
simm=[]

obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/sim_2.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=simm[np.isnan(obss)==False]


SPAef2, alpha2, beta2, gamma2 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef2, alpha2, beta2, gamma2,'Case-2') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map2map') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case2',SPAef2)

############################################################ EXAMPLE: poor match
obs=[]
sim=[]
obss=[]
simm=[]

obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/sim_3.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=simm[np.isnan(obss)==False]

   
SPAef3, alpha3, beta3, gamma3 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef3, alpha3, beta3, gamma3,'Case-3') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map3map') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case3',SPAef3)



############################################################ EXAMPLE: poor match
obs=[]
sim=[]
obss=[]
simm=[]

obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/sim_4.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=simm[np.isnan(obss)==False]


SPAef4, alpha4, beta4, gamma4 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef4, alpha4, beta4, gamma4,'Case-4') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map4map') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case4',SPAef4)


############################################################ EXAMPLE: poor match
obs=[]
sim=[]
obss=[]
simm=[]

obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/sim_5.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=simm[np.isnan(obss)==False]



SPAef5, alpha5, beta5, gamma5 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef5, alpha5, beta5, gamma5,'Case-5shifted') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map5-shifted') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case5',SPAef5)


############################################################ EXAMPLE: shifted cells
obs=[]
sim=[]
obss=[]
simm=[]

obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/sim_6.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=simm[np.isnan(obss)==False]


SPAef6, alpha6, beta6, gamma6 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef6, alpha6, beta6, gamma6,'Case-6') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map6map') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case6',SPAef6)



############################################################ EXAMPLE: biased sim=obsx30 times greater values, locations unchanged
obs=[]
sim=[]
obss=[]
simm=[]

obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/sim_shuffled.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=simm[np.isnan(obss)==False]


SPAef7, alpha7, beta7, gamma7 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef7, alpha7, beta7, gamma7,'Case-7shuffled') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map7-shuffled') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case7',SPAef7)



############################################################ EXAMPLE: biased sim=obs x 1.4 times greater values, locations unchanged
obs=[]
sim=[]
obss=[]
simm=[]

obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/obs.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=obss*1.4


SPAef8, alpha8, beta8, gamma8 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef8, alpha8, beta8, gamma8,'Case-8biased40%') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map8-biased40%') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case8',SPAef8)

############################################################ EXAMPLE: add biased sim=obs+2 constant bias added, locations unchanged
obs=[]
sim=[]
obss=[]
simm=[]

obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/obs.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=obss+2


SPAef9, alpha9, beta9, gamma9 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef9, alpha9, beta9, gamma9,'Case-9PLUS2') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map9-PLUS2') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case9',SPAef9)



############################################################ EXAMPLE: add biased sim=obs^2 (SQUARED) constant bias added, locations unchanged, the need for SPEERMAN
obs=[]
sim=[]
obss=[]
simm=[]

obs=np.loadtxt('./map_files/obs.asc')   
sim=np.loadtxt('./map_files/obs.asc') 

obs[mask_1km==0]=np.nan
sim[mask_1km==0]=np.nan

notnan=np.argwhere(np.isnan(obs)==False)

obss=obs[notnan[:,0],notnan[:,1]]  
simm=sim[notnan[:,0],notnan[:,1]]

obss=obss[np.isnan(obss)==False]
simm=obss**2


SPAef10, alpha10, beta10, gamma10 = SPAEF(simm,obss)
########################################################################        PLOT   MAPS and STATS

plot_SPAEFstats(simm,obss,SPAef10, alpha10, beta10, gamma10,'Case-10SQUARED') # first two inputs should be 1D vector

plot_maps(sim,obs,'Map10-SQUARED') # first two inputs should be 2D matrix (not vector)

print ('SPAEF_case10',SPAef10)



val=np.array([['ID','SPAEF'],['Case1',np.around(SPAef1,7)],['Case2',np.around(SPAef2,7)],['Case3',np.around(SPAef3,7)],['Case4',np.around(SPAef4,7)],['Case5',np.around(SPAef5,7)],['Case6',np.around(SPAef6,7)],['Case7',np.around(SPAef7,7)],['Case8',np.around(SPAef8,7)],['Case9',np.around(SPAef9,7)],['Case10',np.around(SPAef10,7)]])


csvfile = "SPAEF_results.out"

#Assuming res is a flat list
with open('./results/'+csvfile, "w") as output:
    writer = csv.writer(output,delimiter =' ', lineterminator='\n')
    for val in val:
        writer.writerow(val) 
        
### 
output.close()








print ('Welldone')

#sys.modules[__name__].__dict__.clear()



