

cd C:\Users\mcd\Documents\CALIBRATION_mHM\SPAEF_4public\

addpath('C:\Users\mcd\Documents\CALIBRATION_mHM\SPAEF_4public\');
addpath('./matlab_files')


mask = import_2Dmask('.\map_files\mask_1km.asc');

obs = import_2Dmap('.\map_files\obs.asc');


obs_biased=obs;

[row,col]=find(obs>0);

for i=1:length(row)
    for j=1:length(col)

obs_biased(row(i),col(j))=obs(row(i),col(j))*1.2;

    end
end


obs_biased(mask(:,:)==0)=-9999;
