clear
clc

cd C:\Users\mcd\Documents\CALIBRATION_mHM\SPAEF_4public\

addpath('C:\Users\mcd\Documents\CALIBRATION_mHM\SPAEF_4public\');
addpath('./matlab_files')

mask = import_2Dmask('C:\Users\mcd\Documents\CALIBRATION_mHM\SPAEF_4public\map_files\mask_1km.asc');
load  C:\Users\mcd\Documents\CALIBRATION_mHM\MAYobs_array_AET.mat

clear May_biased

May2=May(May>0);

May3=sort(May2);

OrigData=May3;
X=randperm(numel(OrigData));
ShuffledData=reshape(OrigData(X),size(May3));


May_shuf=May;
[rows, cols] =find(May>0);

for i=1:length(rows)
    
May_shuf(rows(i),cols(i))=ShuffledData(i);
    
end

% aa=abs(May_biased-May);

% [row,col]=find(aa>100);
%

% row, col=find(May<0);
% May(row, col)=[];


% load dummy_array_legend_AET
%
% [row,col]=find(DUMMYlegend<0.7 & DUMMYlegend>0);
%
% DUMMYlegend(row,col)=0.7;
%
% [row,col]=find(DUMMYlegend>1.3 & DUMMYlegend>0);
%
% DUMMYlegend(row,col)=1.3;