clear
clc

cd C:\Users\cuneyd\Downloads\SPAEF_4public_org/matlab_files

cd ..

addpath('./matlab_files')
addpath('C:/Users/cuneyd/Downloads/SPAEF_4public_org/matlab_files/')

mask = import_2Dmask('.\map_files\mask_1km.asc');
obs = import_2Dmap('.\map_files\obs.asc');


obs2=obs(obs>0);

obs3=sort(obs2);

OrigData=obs2;
X=randperm(numel(OrigData));
ShuffledData=reshape(OrigData(X),size(obs3));


obs_shuf=obs;
[rows, cols] =find(obs>0);

for i=1:length(rows)
    
obs_shuf(rows(i),cols(i))=ShuffledData(i);
    
end

sim=obs_shuf;

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

[ spaef_9, alpha9, beta9, gamma9 ] = SPAEF_func( sim_vec,obs_vec )

