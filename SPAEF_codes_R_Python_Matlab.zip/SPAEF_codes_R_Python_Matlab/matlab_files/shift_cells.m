clear
clc

cd C:\Users\mcd\Documents\CALIBRATION_mHM\SPAEF_4public\

addpath('C:\Users\mcd\Documents\CALIBRATION_mHM\SPAEF_4public\');
addpath('./matlab_files')


mask = import_2Dmask('.\map_files\mask_1km.asc');

obs = import_2Dmap('.\map_files\obs.asc');

obs2=obs;

obs2(:,15:end)=obs(:,14:end-1);

obs2(mask(:,:)==0)=-9999;

aa=abs(obs-obs2);

[row,col]=find(aa>100);

obs2(row,col)=obs(row,col);

aa=abs(obs-obs2);

[row,col]=find(aa>100);

Shifted=obs2;

