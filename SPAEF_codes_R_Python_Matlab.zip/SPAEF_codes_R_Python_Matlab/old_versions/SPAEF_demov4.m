clear
clc
close all

addpath('.\matlab_files')

mask = import_2Dmask('.\map_files\mask_1km.asc');

obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_1.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

bins=100;

[ spaef_1 ] = SPAEF_func( sim_vec,obs_vec,bins );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_2.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

bins=100;

[ spaef_2 ] = SPAEF_func( sim_vec,obs_vec,bins );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_3.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

bins=100;

[ spaef_3 ] = SPAEF_func( sim_vec,obs_vec,bins );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_4.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

bins=100;

[ spaef_4 ] = SPAEF_func( sim_vec,obs_vec,bins );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_5.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

bins=100;

[ spaef_5 ] = SPAEF_func( sim_vec,obs_vec,bins );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_6.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

bins=100;

[ spaef_6 ] = SPAEF_func( sim_vec,obs_vec,bins );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_7.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

bins=100;

[ spaef_7 ] = SPAEF_func( sim_vec,obs_vec,bins );

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
obs = import_2Dmap('.\map_files\obs.asc');
sim = import_2Dmap('.\map_files\sim_8.asc');

obs(mask(:,:)==0)=NaN;
sim(mask(:,:)==0)=NaN;

obs_vec=obs(~isnan(obs));
sim_vec=sim(~isnan(sim));

bins=100;

[ spaef_8 ] = SPAEF_func( sim_vec,obs_vec,bins );



fileID = fopen('.\results\SPAEF_results.txt','w');
fprintf(fileID,'%5s %5s \r\n','ID','SPAEF') 
fprintf(fileID,'%3s %.6f \r\n','Case1', spaef_1 ,'Case2',spaef_2,'Case3',spaef_3,'Case4',spaef_4,'Case5',spaef_5,'Case6',spaef_6,'Case7',spaef_7,'Case8',spaef_8);


