
#This is a R script to calculate spatial efficiency (SPAEF) which can be used to compare spatial patterns in two raster maps 
#Note that the "no values (here -9999)" in 2D maps are cleared first. Observed and Simulated two arrays (2D) are provided to the function.

#Detailed explanation goes here

#The newly proposed spatial efficiency metric (SPAEF) is proven to be robust 
#and easy to interpret due to its three distinct and complementary components of correlation, variance and histogram matching.

#Created on Wed Feb 6 2019
#@ authors:                 Mehmet C�neyd Demirel
#@ author's website:        http://www.space.geus.dk/
#@ author's webpage:        http://akademi.itu.edu.tr/demirelmc/
#@ author's email id:     demirelmc@itu.edu.tr
#
#A libray with R functions for calculation of spatial efficiency (SPAEF) metric.
#
#Literature:
#
# [1] Demirel, M. C., Mai, J., Mendiguren, G., Koch, J., Samaniego, L., & Stisen, S. (2018). Combining satellite data and appropriate objective functions for improved spatial pattern performance of a distributed hydrologic model. Hydrology and Earth System Sciences, 22(2), 1299-1315. https://doi.org/10.5194/hess-22-1299-2018
# [2] Koch, J., Demirel, M. C., & Stisen, S. (2018). The SPAtial EFficiency metric (SPAEF): multiple-component evaluation of spatial patterns for optimization of hydrological models. Geoscientific Model Development, 11(5), 1873-1886. https://doi.org/10.5194/gmd-11-1873-2018

#clean Global Environment
rm(list=ls()) 

# WD: working directory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #For Rstudio users

WD <- getwd()
# setwd("D:/SPAEF_4_R_users")
# install.packages("pracma") #histc is in pracma

library(pracma)

# read ascii
mask <- read.delim('./mask_1km.asc', header = FALSE, sep = ",", dec = ".")
dimens=dim(mask)
mask=array(as.numeric(unlist(mask)), dim=c(dimens[1], dimens[2]))

  
map1 <- read.delim('./obs.asc', header = FALSE, sep = "\t", dec = ".")
map2 <- read.delim('./sim_4.asc', header = FALSE, sep = "\t", dec = ".")



x1 <- map1[ map1 != -9999 ]
x2 <- map2[ map2 != -9999 ]
mask <- mask[ mask != -9999 ]

v[as.logical(m)]

#CORR
cc=cor(x1,x2)

#coefficient of variation
cv_obs=sd(x1)/mean(x1);
cv_sim=sd(x2)/mean(x2);

alpha=cv_sim/cv_obs;

#HISTOmatch
x1=(x1-mean(x1))/sd(x1)
x2=(x2-mean(x2))/sd(x2)

h1 <- hist(x1, breaks=100, freq=TRUE, plot=TRUE)
h2 <- hist(x2, breaks=100, freq=TRUE, plot=TRUE) #False makes Density instead of frequency, try it

a=histc(x1, h1$breaks)
b=histc(x2, h1$breaks)
c=cbind(a$cnt, b$cnt)
d <- pmin(c[,1],c[,2])
overlap=sum(d)
histogram_match=overlap/sum(a$cnt)


spaef = 1- sqrt( (cc-1)^2 + (alpha-1)^2 + (histogram_match-1)^2 )


